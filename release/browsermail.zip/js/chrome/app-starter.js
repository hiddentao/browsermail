/**
 * Need by Chrome packaged app HTML page to kick start the app, because inline JS not allowed due to CSP
 */

window.app.require('app');
